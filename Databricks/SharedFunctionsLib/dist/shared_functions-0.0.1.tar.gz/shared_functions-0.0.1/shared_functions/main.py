def main():
    print("Hello from shared_functions.main.main!")